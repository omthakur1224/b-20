### Instructions to follow before Starting class:

1.  Clone: [https://github.com/riteshf/lec](https://github.com/riteshf/lec)
2.  cd lec
3.  npm i
4.  npm start

### To start Server run followig command

- `json-server --watch db.json --port 8080`

## Note:

- Go through the code to understand the structure.
