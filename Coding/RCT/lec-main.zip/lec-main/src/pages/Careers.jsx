import React from "react";

const Careers = () => {
  return <div>Random Page without auth</div>;
};

export default Careers;
